// Copyright Epic Games, Inc. All Rights Reserved.

#include "HackAndSlashCpp.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, HackAndSlashCpp, "HackAndSlashCpp" );
 