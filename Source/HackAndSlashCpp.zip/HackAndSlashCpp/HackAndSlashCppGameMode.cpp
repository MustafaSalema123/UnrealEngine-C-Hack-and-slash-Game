// Copyright Epic Games, Inc. All Rights Reserved.

#include "HackAndSlashCppGameMode.h"
#include "HackAndSlashCppCharacter.h"
#include "UObject/ConstructorHelpers.h"

AHackAndSlashCppGameMode::AHackAndSlashCppGameMode()
{
	// set default pawn class to our Blueprinted character
	static ConstructorHelpers::FClassFinder<APawn> PlayerPawnBPClass(TEXT("/Game/ThirdPersonCPP/Blueprints/MyCharacterController_Bp"));
	if (PlayerPawnBPClass.Class != NULL)
	{
		DefaultPawnClass = PlayerPawnBPClass.Class;
	}
}
