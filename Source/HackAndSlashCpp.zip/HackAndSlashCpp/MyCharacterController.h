// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "MyCharacterController.generated.h"

UENUM(BlueprintType)    //Enum of movement stats
enum class ECombatState : uint8
{
	ECS_Nothing UMETA(DisplayName = "Nothing"),
	ECS_Attack UMETA(DisplayName = "Attack"),
	ECS_Dodge UMETA(DisplayName = "d"),

	EMS_MAX UMETA(DisplayName = "DefaultMAX")
};

UCLASS()
class HACKANDSLASHCPP_API AMyCharacterController : public ACharacter
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	AMyCharacterController();

	/** Base turn rate, in deg/sec. Other scaling may affect final turn rate. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category=Camera)
	float BaseTurnRate;

	/** Base look up/down rate, in deg/sec. Other scaling may affect final rate. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category=Camera)
	float BaseLookUpRate;

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

private:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera, meta = (AllowPrivateAccess = "true"))
   	class USpringArmComponent* CameraBoom;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera, meta = (AllowPrivateAccess = "true"))
	class UCameraComponent* CameraFollow;
	



private:
	void MoveRight(float Value);
	void Moveforward(float Value);

	/** 
	 * Called via input to turn at a given rate. 
	 * @param Rate	This is a normalized rate, i.e. 1.0 means 100% of desired turn rate
	 */
	void TurnAtRate(float Rate);

	/**
	 * Called via input to turn look up/down at a given rate. 
	 * @param Rate	This is a normalized rate, i.e. 1.0 means 100% of desired turn rate
	 */
	void LookUpAtRate(float Rate);
	
	

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Enums")
	ECombatState currentState;   //enum of Movemnent status

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Anims")
	class UAnimMontage* LightAttackMontage;   //Combat animation

	 UPROPERTY(EditAnywhere, Category = "LightAttack")
    int32 MaxAnimationsInMontage; // Maximum number of animations in the montage

    UPROPERTY(BlueprintReadOnly, Category = "LightAttack")
    int32 LightAttackIndex; // Current index for light attack

    UFUNCTION(BlueprintCallable, Category = "LightAttack")
    void DoLightAttack();

	public :
	
	FORCEINLINE ECombatState GetState() const { return }
	void SetMovementStatus(ECombatState currentState);  
};
