// Fill out your copyright notice in the Description page of Project Settings.


#include "MyCharacterController.h"
#include "GameFramework/SpringArmComponent.h"
#include "Camera/CameraComponent.h"

#include "GameFramework/CharacterMovementComponent.h"
// Sets default values
AMyCharacterController::AMyCharacterController()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	CameraBoom = CreateDefaultSubobject<USpringArmComponent>(FName("Camera Boom"));
	CameraBoom->SetupAttachment(GetRootComponent());
	CameraBoom->TargetArmLength = 300.0f;
	CameraBoom->bUsePawnControlRotation = true; // Rotate the arm based on the controller

	CameraFollow = CreateDefaultSubobject<UCameraComponent>(FName("Text Camera"));
	CameraFollow->SetupAttachment(CameraBoom ,  USpringArmComponent::SocketName);
	CameraFollow->bUsePawnControlRotation = false; // Camera does not rotate relative to arm

	BaseTurnRate = 45.0f;
	BaseLookUpRate = 45.0f;
	// Don't rotate when the controller rotates. Let that just affect the camera.
	bUseControllerRotationPitch = false;
	bUseControllerRotationYaw = false;
	bUseControllerRotationRoll = false;

	GetCharacterMovement()->bOrientRotationToMovement = true;
	GetCharacterMovement()->RotationRate = FRotator(0.0f, 540.0f, 0.0f); // ...at this rotation rate
	GetCharacterMovement()->JumpZVelocity = 400.f;

}

// Called when the game starts or when spawned
void AMyCharacterController::BeginPlay()
{
	Super::BeginPlay();
	
}

void AMyCharacterController::MoveRight(float Value)
{
if ( (Controller != nullptr) && (Value != 0.0f) )
	{
		// find out which way is right
		const FRotator Rotation = Controller->GetControlRotation();
		const FRotator YawRotation(0, Rotation.Yaw, 0);
	
		// get right vector 
		const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);
		// add movement in that direction
		AddMovementInput(Direction, Value);
	}
}

void AMyCharacterController::Moveforward(float Value)
{
	if ((Controller != nullptr) && (Value != 0.0f))
	{
		// find out which way is forward
		const FRotator Rotation = Controller->GetControlRotation();
		const FRotator YawRotation(0, Rotation.Yaw, 0);

		// get forward vector
		const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);
		AddMovementInput(Direction, Value);
	}
}

void AMyCharacterController::TurnAtRate(float Rate)
{
		// calculate delta for this frame from the rate information
	AddControllerYawInput(Rate * BaseTurnRate * GetWorld()->GetDeltaSeconds());
}

void AMyCharacterController::LookUpAtRate(float Rate)
{
		// calculate delta for this frame from the rate information
	AddControllerPitchInput(Rate * BaseLookUpRate * GetWorld()->GetDeltaSeconds());
}

// Called every frame
void AMyCharacterController::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AMyCharacterController::DoLightAttack()
{
	
    if (LightAttackMontage)
    {
        UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();
        if (AnimInstance)
        {
            if (LightAttackIndex < MaxAnimationsInMontage)
            {
                // Play the next animation in the montage
                 FString SectionName = FString::Printf(TEXT("l_Attack%d"), LightAttackIndex + 1); // Assuming section names are Attack1, Attack2, etc.

                // Play the specific section of the montage
				AnimInstance->Montage_Play(LightAttackMontage, 1.f, EMontagePlayReturnType::MontageLength, 0.f, true);
              //  AnimInstance->Montage_Play(LightAttackMontage, 1.f);
                AnimInstance->Montage_JumpToSection(*SectionName);

                LightAttackIndex++;
                // If the index reaches the maximum, reset it
                if (LightAttackIndex >= MaxAnimationsInMontage)
                {
					 LightAttackIndex = 0;
                   // ResetLightAttackIndex();
                }
            }
        }
    }
}
// Called to bind functionality to input
void AMyCharacterController::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	check(PlayerInputComponent);
	PlayerInputComponent->BindAxis("MoveForward" , this , &AMyCharacterController::Moveforward);
	PlayerInputComponent->BindAxis("MoveRight" , this , &AMyCharacterController::MoveRight);

	PlayerInputComponent->BindAction("Jump" , IE_Pressed , this , &ACharacter::Jump);
	PlayerInputComponent->BindAction("Jump" , IE_Released , this , &ACharacter::StopJumping);

	PlayerInputComponent->BindAxis("Turn", this, &APawn::AddControllerYawInput);
	PlayerInputComponent->BindAxis("TurnRate", this, &AMyCharacterController::TurnAtRate);
	PlayerInputComponent->BindAxis("LookUp", this, &APawn::AddControllerPitchInput);
	PlayerInputComponent->BindAxis("LookUpRate", this, &AMyCharacterController::LookUpAtRate);

	//PlayerInputComponent->BindAction("MouseLeftButton")
	PlayerInputComponent->BindAction("LeftMouseB" , IE_Pressed , this , &AMyCharacterController::DoLightAttack);
}

